class ChatManager extends BaseClass{
	public constructor() {
		super();
	}
}