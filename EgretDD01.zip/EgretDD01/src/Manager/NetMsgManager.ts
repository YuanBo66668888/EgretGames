class NetMsgManager extends BaseClass {
	public constructor() {
		super();
	}
}