class BagManager extends BaseClass {
	public constructor() {
		super();
	}
}