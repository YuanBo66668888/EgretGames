class UnionDataManager extends BaseClass {
	public constructor() {
		super();
	}
}