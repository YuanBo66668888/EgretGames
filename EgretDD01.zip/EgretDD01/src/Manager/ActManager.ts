class ActManager extends BaseClass {
	public constructor() {
		super();
	}
}