class ReportManager extends BaseClass {
	public constructor() {
		super();
	}
}