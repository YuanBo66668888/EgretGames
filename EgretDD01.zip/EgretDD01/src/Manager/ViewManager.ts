class ViewManager extends BaseClass {
	public constructor() {
		super();
	}
}