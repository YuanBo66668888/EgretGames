class TaskManager extends BaseClass {
	public constructor() {
		super();
	}
}