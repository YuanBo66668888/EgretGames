class WarManager extends BaseClass {
	public constructor() {
		super();
	}
}