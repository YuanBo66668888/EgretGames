class TimerManager extends BaseClass {
	public constructor() {
		super();
	}
}