class MailManager extends BaseClass {
	public constructor() {
		super();
	}
}