class SceneManager extends BaseClass {
	public constructor() {
		super();
	}
}