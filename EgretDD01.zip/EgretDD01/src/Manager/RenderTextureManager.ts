class RenderTextureManager extends BaseClass {
	public constructor() {
		super();
	}
}