class ResVersionManager extends BaseClass {
	public constructor() {
		super();
	}
}