class ControllerManager extends BaseClass {
	public constructor() {
		super();
	}
}