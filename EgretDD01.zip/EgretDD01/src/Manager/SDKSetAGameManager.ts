class SDKSetAGameManager extends BaseClass {
	public constructor() {
		super();
	}
}