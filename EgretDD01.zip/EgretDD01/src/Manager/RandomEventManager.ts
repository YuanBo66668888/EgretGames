class RandomEventManager extends BaseClass{
	public constructor() {
		super();
	}
}