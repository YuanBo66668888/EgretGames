class PanelManager extends BaseClass {
	public constructor() {
		super();
	}
}