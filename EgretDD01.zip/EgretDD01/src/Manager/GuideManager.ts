class GuideManager extends BaseClass {
	public constructor() {
		super();
	}
}