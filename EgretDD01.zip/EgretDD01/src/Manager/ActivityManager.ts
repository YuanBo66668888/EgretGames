class ActivityManager extends BaseClass {
	public constructor() {
		super();
	}
}