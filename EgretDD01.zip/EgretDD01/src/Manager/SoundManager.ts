class SoundManager extends BaseClass {
	public constructor() {
		super();
	}
}