class LayerManager {
	public constructor() {
	}
}