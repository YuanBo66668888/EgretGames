class DateUtils extends BaseClass {
	public constructor() {
		super();
	}

	public getFormatBySecond() {

	}

	public getFormatBySecond1() {
		
	}
}