class EgretExpandUtils extends BaseClass {
	public constructor() {
		super();
	}

	public init() {
		AnchorUtils.init();
	}
}