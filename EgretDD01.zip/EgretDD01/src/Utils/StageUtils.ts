class StageUtils extends BaseClass {
	public constructor() {
		super();
	}
}