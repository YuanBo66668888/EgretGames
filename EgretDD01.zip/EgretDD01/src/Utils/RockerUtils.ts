class RockerUtils extends BaseClass {
	public constructor() {
		super();
	}
}