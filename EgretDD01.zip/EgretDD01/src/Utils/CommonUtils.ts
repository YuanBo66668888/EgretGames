class CommonUtils extends BaseClass {
	public constructor() {
		super();
	}

	public NumberToDisplayString(num:number) {
		
	}
}