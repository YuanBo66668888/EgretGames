class KeyboardUtils extends BaseClass {
	public constructor() {
		super();
	}
}