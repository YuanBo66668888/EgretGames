class ShockUtils extends BaseClass {
	public constructor() {
		super();
	}
}