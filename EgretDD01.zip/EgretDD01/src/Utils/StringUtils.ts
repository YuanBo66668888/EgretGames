class StringUtils extends BaseClass {
	public constructor() {
		super();
	}
}