class ResourceUtils extends BaseClass {
	public constructor() {
		super();
	}
}