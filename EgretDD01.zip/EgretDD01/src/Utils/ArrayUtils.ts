class ArrayUtils extends BaseClass {
	public constructor() {
		super();
	}

	public forEach() {

	}
}