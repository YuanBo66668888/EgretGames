class EffectUtils extends BaseClass {
	public constructor() {
		super();
	}

	public macIconShake() {

	}

	public startFlicker() {

	}

	public stopFlicker() {
		
	}
}