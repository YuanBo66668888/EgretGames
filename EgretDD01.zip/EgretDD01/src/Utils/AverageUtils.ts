class AverageUtils extends BaseClass {
	public constructor() {
		super();
	}

	public push() {

	}

	public getValue() {

	}

	public clear() {
		
	}
}