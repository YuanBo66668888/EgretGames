class LoadingController {
	public constructor() {
	}
}