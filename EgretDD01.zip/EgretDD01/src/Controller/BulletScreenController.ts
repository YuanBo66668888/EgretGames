class BulletScreenController extends BaseController {
	public constructor() {
		super();
	}
}