class JehadController {
	public constructor() {
	}
}