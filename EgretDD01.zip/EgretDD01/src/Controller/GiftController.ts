class GiftController extends BaseController {
	public constructor() {
		super();
	}
}