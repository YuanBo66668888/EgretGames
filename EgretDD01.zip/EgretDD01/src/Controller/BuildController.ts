class BuildController extends BaseController {
	public constructor() {
		super();
	}
}