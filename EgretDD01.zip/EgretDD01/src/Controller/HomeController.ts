class HomeController {
	public constructor() {
	}
}