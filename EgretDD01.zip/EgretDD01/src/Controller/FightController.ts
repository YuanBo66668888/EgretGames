class FightController extends BaseController {
	public constructor() {
		super();
	}
}