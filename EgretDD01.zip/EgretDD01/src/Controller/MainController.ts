class MainController {
	public constructor() {
	}
}