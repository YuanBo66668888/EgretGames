class GuideController extends BaseController {
	public constructor() {
		super();
	}
}