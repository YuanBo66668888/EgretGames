class LoginController {
	public constructor() {
	}
}