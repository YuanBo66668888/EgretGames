class BaseScene {
	public constructor() {
	}
}