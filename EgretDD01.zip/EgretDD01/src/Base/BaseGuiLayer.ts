class BaseGuiLayer extends eui.Group {
	public constructor() {
		super();
		this.percentWidth = 100;
		this.percentHeight = 100;
	}
}