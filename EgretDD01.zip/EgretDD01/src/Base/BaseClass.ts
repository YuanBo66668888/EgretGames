class BaseClass {

	public static _instance;
	public constructor(...args) {
	}

	public static getInstance() {
		for (var params = [], i = 0; i < arguments.length; i++) {
			params[i] = arguments[i];
		}
		if (!this._instance) {
			var n = params.length;
			if (n == 0) {
				this._instance = new BaseClass();
			} else if (n == 1) {
				this._instance = new BaseClass(params[0]);
			} else if (n == 2) {
				this._instance = new BaseClass(params[0], params[1])
			} else if (n == 3) {
				this._instance = new BaseClass(params[0], params[1], params[2])
			} else if (n == 4) {
				this._instance = new BaseClass(params[0], params[1], params[2], params[3]);
			} else if (n == 4) {
				this._instance = new BaseClass(params[0], params[1], params[2], params[3], params[4]);
			}
		}
		return this._instance;
	}
}