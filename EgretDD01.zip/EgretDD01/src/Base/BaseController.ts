class BaseController {
	public constructor() {
	}
}