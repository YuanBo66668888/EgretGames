class BaseProxy {
	public constructor() {
	}
}