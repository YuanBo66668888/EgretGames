class LoadingUI {
	public constructor() {
	}
}