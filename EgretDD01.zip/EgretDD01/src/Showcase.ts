class Showcase {
	public constructor() {
	}
}