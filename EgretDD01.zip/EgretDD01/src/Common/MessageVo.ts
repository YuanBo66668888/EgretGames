class MessageVo {
	public type;
	public param;
	public constructor() {
	}

	public dispose() {
		this.type = null;
		this.param = null;
	}
}