class BitmapNumber extends BaseClass {
	public constructor() {
		super();
	}

	public createNumPic() {

	}

	public desstroyNumPic() {
		
	}

	public changeNum() {

	}

	public repositionNumPic() {

	}

	public clearContainer() {

	}

	public recycleBM() {

	}

	public getContainer() {

	}

	public getSingleNumPic() {

	}

	public getTexture() {
		
	}

	public getBitmap() {

	}
}