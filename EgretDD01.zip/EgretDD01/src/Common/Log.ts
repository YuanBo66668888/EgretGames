class Log {
	public constructor() {
	}

	public static trace(...param) {
		for (var t = [], e = 0; e < arguments.length; e++) t[e - 0] = arguments[e];
	}
}