class Lan extends BaseClass {
	public constructor() {
		super();
	}
}