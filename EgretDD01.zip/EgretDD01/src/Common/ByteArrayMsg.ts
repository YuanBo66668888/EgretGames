class ByteArrayMsg {
	private _msgBuffer:egret.ByteArray;
	public constructor() {
		this._msgBuffer = new egret.ByteArray;
	}

	public receive = function() {

	}

	public send() {

	}

	public decode() {

	}

	public encode() {
		
	}
}