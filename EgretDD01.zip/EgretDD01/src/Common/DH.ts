class DH {
	public constructor() {
	}
}