class Ws extends BaseClass {
	public constructor() {
		super();
	}
}