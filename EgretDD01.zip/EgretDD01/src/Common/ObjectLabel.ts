class ObjectLabel {
	public constructor() {
	}
}