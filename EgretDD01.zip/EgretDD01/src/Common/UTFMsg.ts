class UTFMsg {
	public constructor() {
		
	}

	public receive() {

	}

	public send() {

	}

	public decode() {

	}

	public encode() {
		
	}
}