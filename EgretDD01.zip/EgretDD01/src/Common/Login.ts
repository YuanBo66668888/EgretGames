class Login extends BaseClass {
	public constructor() {
		super();
	}
}