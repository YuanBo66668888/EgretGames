class GameNote {
	public static inited;
	public constructor() {
		GameNote.inited = false;
	}

	public static init() {

	}

	public static initLabel() {

	}

	public static note(k, v) {

	}

	public static ClickMaxNote() {

	}

	public static hideLabel() {
		
	}
}