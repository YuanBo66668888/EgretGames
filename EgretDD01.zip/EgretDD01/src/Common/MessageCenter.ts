class MessageCenter extends BaseClass {
	
	public type;
	public dict;
	public eVec;
	public lastRunTime;

	public constructor(tp:string) {
		super();
		this.type = tp;
		Log.trace("constructorMessg:" + this.type);
		this.dict = {}
		this.eVec = new Array;
		this.lastRunTime = 0

		if (0 == this.type) {
			// App.TimerManager.doFrame(1, 0, this.run, this, null);
		}
	}

	public run() {
		var t = egret.getTimer();
		var dt = t - this.lastRunTime > 100;
		if (dt) {
			this.lastRunTime = t;
			for (; this.eVec.length > 0;) {

			}
		}
	}

	public dealMsg(msg) {
		var all = this.dict[msg.type];
		for (var i = 0, total = all.length, s = null; total > i;) {
			s = this.dict[msg.type];
			s[0].apply(s[1], msg.param);
			//
		}
	}
}