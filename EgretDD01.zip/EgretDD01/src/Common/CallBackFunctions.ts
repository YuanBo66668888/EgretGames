class CallBackFunctions {
	public constructor() {
	}
}