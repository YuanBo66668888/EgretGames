class ProxyUpdate {
	
	private _cache;
	private _proxys;

	public constructor(data) {
		this._cache = data;
		this._proxys = [];
	}

	public isArray(arr) {
		return arr instanceof Array;
	}

	public isObject(object) {
		return object.indexOf("object") > -1;
	}

	public isNormal(o) {
		var e = o.indexOf("@") > -1,
        i = o.indexOf(".") > -1,
        n = o.indexOf("_") > -1;
        return !e && !i && !n
	}

	public isAddToArray(o) {
		return "@a" == o;
	}

	public isRemoveToArray(o) {
		var e = o.split("_");
        return e.length <= 3 && "@d" == e[0]
	}

	public isFilter(o) {
		var e = o.split("_");
        return "@f" == e[0]
	}

	public isNumeric(o) {
		return parseFloat(o).toString() == o.toString()
	}

	private _updateObject(o, obj, arr) {
		var n = o.split(".");
        "@a" == n[0] || "@s" == n[0] ? arr[n[1]] = obj: "@d" == n[0] && delete obj[n[1]]
	}

	private _getFilterObject(obj, arr) {
		if (arr) {
            var i = obj.split("_");
            if (3 == i.length && "@f" == i[0] && this.isArray(arr)) for (var n = i[1], s = i[2], r = 0; r < arr.length; r++) {
                var a = arr[r];
                if (3 == i.length && this.isObject(a.toString())) {
                    var o = a[n];
                    if (o && ("@" == s[0] && (s = s.replace("@", "")), s == o)) return a
                }
            }
        }
        return null
	}

	private _addObjectToArray(arr, obj) {
		if (this.isArray(obj)) for (var i = 0; i < obj.length; i++) arr.push(obj[i]);
        else arr.push(obj)
	}

	// TODO
	private _removeObjectFromArray() {
		
	}

	public addProxys(key, value) {
		if (!this._proxys[key]) {
			this._proxys[key] = []
		}
		if (-1 == this._proxys[key].indexOf(value)) {
			this._proxys[key].push(value)
		}
	}

	public update() {
		// TODO
	}

	private _update()  {
		// TODO
	}

	
}