class Http extends BaseClass {
	
	private _data;
	private _cache:Array<any>;
	private _request:egret.URLRequest;
	private _urlLoader:egret.URLLoader;
	public get_cache;
	private _urlResLoader;
	private _isRequesting;
	private _type;

	private _serverUrl;
	
	public constructor() {
		super();
		this._cache = [];
		this._data = new DynamicChange();
		//
		this._request = new egret.URLRequest;
		this._request.method = egret.URLRequestMethod.POST;
		
		// 
		this._urlLoader = new egret.URLLoader;
		this._urlLoader.addEventListener(egret.IOErrorEvent.IO_ERROR, this.onError, this);
	}

	public onLoadError() {
		
	}

	public initServer(url) {
		this._serverUrl = url;
		this._request.url = this._serverUrl;
	}

	public get Data() {
		return this._data;
	}

	public onError() {
		this.nextPost();
	}

	public send(k, v) {
		this._cache.push([k, v]);
		this.post();
	}

	public HttpGetRes(k, v) {

	}

	public onGet() {

	}
	
	public nextOnGet() {

	}

	public get(k, v) {

	}

	public onHttpGetComplete() {

	}

	public onGetComplete() {

	}

	public post() {
		if (!this._isRequesting && 0 != this._cache.length) {
			var dat_arr = this._cache.shift();
			var type = dat_arr[0];
			var data = dat_arr[1];

			this._type = type;
			this._request.data = data;
			this._urlLoader.addEventListener(egret.Event.COMPLETE, this.onLoaderComplete, this);
			this._urlLoader.load(this._request),
            this._isRequesting = !0
		}
	}

	public onLoaderComplete() {
		this._urlLoader.removeEventListener(egret.Event.COMPLETE, this.onLoaderComplete, this);
		var json_dat = JSON.parse(this._urlLoader.data);
		// json_dat.hasOwnProperty("s") && 0 != json_dat.s ? Log.trace("Http错误:" + json_dat.s) : (this._data.pUpdate.update(this._type, json_dat), App.MessageCenter.dispatch(this._type, json_dat)),
	}

	public nextPost() {
		this._isRequesting = !1;
	}
}