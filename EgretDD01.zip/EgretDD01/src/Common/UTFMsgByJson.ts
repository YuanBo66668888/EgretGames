class UTFMsgByJson extends UTFMsg {
	public constructor() {
		super();	
	}

	public decode() {

	}

	public encode() {
		
	}
}