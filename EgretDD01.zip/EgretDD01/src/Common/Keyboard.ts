class Keyboard {
	public constructor() {
	}

	public static LEFT:number = 37;
	public static RIGHT:number = 37;
	public static UP:number = 37;
	public static DOWN:number = 37;
	public static W:number = 37;
	public static A:number = 37;
	public static S:number = 37;
	public static D:number = 37;
	public static J:number = 37;
	public static K:number = 37;
	public static L:number = 37;
	public static U:number = 37;
	public static I:number = 37;
	public static O:number = 38;
	public static P:number = 39;

}