class Socket extends BaseClass {
	public constructor() {
		super();
	}
}