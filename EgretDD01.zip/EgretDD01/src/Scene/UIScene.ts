class UIScene {
	public constructor() {
	}
}