class LoadingScene {
	public constructor() {
	}
}