class Main {
	public constructor() {
	}
}