class MatConst {
	public constructor() {
	}

	public static getMatType(type) {

	}

	public static Gold = 101;
	public static Honor = 102;
    public static Food = 103;
    public static Wood = 104;
    public static Stone = 105;
    public static Metal = 106;
    public static Skin = 107;
    public static Horse = 108;
    public static Jade = 109;
    public static Holy = 110;
    public static Foot = 111;
    public static Bow = 112;
    public static Knight = 113;
    public static Dragon = 114;
    public static Achieve = 115;
    public static Land = 116;
    public static Gang = 117;
    public static Yin = 118;
    public static Power = 120;
    public static Max = 17;
    public static NoType = 0;
    public static BaseType = 1;
    public static CostType = 2;
    public static ArmyType = 3;
}