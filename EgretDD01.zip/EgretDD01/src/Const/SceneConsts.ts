class SceneConsts {
	public constructor() {
	}

	public static Game = 1;
	public static UI = 2;
	public static LOADING = 3;
}