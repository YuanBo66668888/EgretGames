class LoadingConst {
	public constructor() {
	}
}