class FightConst {
	public constructor() {
	}
}