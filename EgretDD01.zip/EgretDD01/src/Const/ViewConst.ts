class ViewConst {
	public constructor() {
	}

	public static Loading = 1e4;
    public static Login = 10001;
    public static Main = 10002;
    public static Border = 10003;
    public static Home = 100021;
    public static Build = 100022;
    public static Army = 100023;
    public static Skill = 100024;
    public static Union = 100025;
    public static Shop = 100026;
    public static Set = 100027;
    public static Fight = 100028;
    public static Jehad = 100029;
    public static UnionDonateFood = 100400;
    public static UnionDonateWood = 100401;
    public static UnionDonateStone = 100402;
    public static JoinUnion = 100403;
    public static UnionNone = 100404;
    public static BuildUnion = 100405;
    public static CreateUnion = 100406;
    public static UnionFlagPanel = 100407;
    public static InputPanel = 100408;
    public static ChatPanel = 100409;
    public static MsgPanel = 1004010;
    public static Friend = 110003;
    public static Warehouse = 110005;
    public static Factory = 110006;
    public static Task = 110007;
    public static Daily = 110008;
    public static Mail = 110009;
    public static Game = 2e4;
    public static GameUI = 20001;
    public static SignInPanel = 15001;
    public static ActivityPanel = 15002;
    public static SignInWeekPanel = 15003;
    public static BulletScreen = 15004;
}