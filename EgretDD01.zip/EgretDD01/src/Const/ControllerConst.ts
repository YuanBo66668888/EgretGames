class ControllerConst {
	public constructor() {
	}

	public static Loading = 1e4;
	public static Login = 10001;
    public static Main = 10002;
    public static Border = 10003;
    public static Home = 100021
    public static Build = 100022
    public static Army = 100023
    public static Skill = 100024
    public static Union = 100025
    public static Shop = 100026
    public static Set = 100027
    public static Fight = 100028
    public static Jehad = 100029
    public static Game = 2e4
    public static Panel = 20001
    public static BulletScreen = 20002
    public static Gift = 30001
}