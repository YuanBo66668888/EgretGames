class GuideConst {
	public constructor() {
	}
}