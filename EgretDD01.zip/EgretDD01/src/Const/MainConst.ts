class MainConst {
	public constructor() {
	}
}