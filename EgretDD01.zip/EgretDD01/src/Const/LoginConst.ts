class LoginConst {
	public constructor() {
	}
}