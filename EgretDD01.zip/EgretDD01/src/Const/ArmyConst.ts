class ArmyConst {
	public constructor() {
	}
}