class BulletScreenConst {
	public constructor() {
	}
}