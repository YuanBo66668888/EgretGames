class HttpConst {
	public constructor() {
	}

	public static USER_LOGIN = "User.login";
}