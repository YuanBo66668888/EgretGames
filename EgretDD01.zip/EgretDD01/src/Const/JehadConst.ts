class JehadConst {
	public constructor() {
	}
}