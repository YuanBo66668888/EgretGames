class NationConsts {
	public constructor() {
	}

	public static NEED_NUMBER = 1e5;
	public static NANTION_ITEM = 55001;
	public static FREE_COUNT = 1;
	public static COST_ITEM = 1;
	public static COST_GOLD = 500;
	public static COST_SOURCE = 1e3;
}