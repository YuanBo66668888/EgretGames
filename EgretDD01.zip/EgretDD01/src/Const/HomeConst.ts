class HomeConst {
	public constructor() {
	}
}