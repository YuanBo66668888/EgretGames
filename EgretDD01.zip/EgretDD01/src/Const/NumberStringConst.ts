class NumberStringConst {
	public constructor() {
	}

	public static K_MIN:number = 1e3;
	public static M_MIN:number = 1e6;
	public static G_MIN:number = 1e9;
	public static T_MIN:number = 1e12;
	public static P_MIN:number = 1e15;
}