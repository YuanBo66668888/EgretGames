class GameMain {
	public constructor() {
	}
}