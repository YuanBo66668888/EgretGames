var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var MessageCenter = (function (_super) {
    __extends(MessageCenter, _super);
    function MessageCenter(tp) {
        var _this = _super.call(this) || this;
        _this.type = tp;
        Log.trace("constructorMessg:" + _this.type);
        _this.dict = {};
        _this.eVec = new Array;
        _this.lastRunTime = 0;
        if (0 == _this.type) {
        }
        return _this;
    }
    MessageCenter.prototype.run = function () {
        var t = egret.getTimer();
        var dt = t - this.lastRunTime > 100;
        if (dt) {
            this.lastRunTime = t;
            for (; this.eVec.length > 0;) {
            }
        }
    };
    MessageCenter.prototype.dealMsg = function (msg) {
        var all = this.dict[msg.type];
        for (var i = 0, total = all.length, s = null; total > i;) {
            s = this.dict[msg.type];
            s[0].apply(s[1], msg.param);
        }
    };
    return MessageCenter;
}(BaseClass));
__reflect(MessageCenter.prototype, "MessageCenter");
//# sourceMappingURL=MessageCenter.js.map