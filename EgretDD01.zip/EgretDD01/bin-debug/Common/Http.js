var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var Http = (function (_super) {
    __extends(Http, _super);
    function Http() {
        var _this = _super.call(this) || this;
        _this._cache = [];
        _this._data = new DynamicChange();
        //
        _this._request = new egret.URLRequest;
        _this._request.method = egret.URLRequestMethod.POST;
        // 
        _this._urlLoader = new egret.URLLoader;
        _this._urlLoader.addEventListener(egret.IOErrorEvent.IO_ERROR, _this.onError, _this);
        return _this;
    }
    Http.prototype.onLoadError = function () {
    };
    Http.prototype.initServer = function (url) {
        this._serverUrl = url;
        this._request.url = this._serverUrl;
    };
    Object.defineProperty(Http.prototype, "Data", {
        get: function () {
            return this._data;
        },
        enumerable: true,
        configurable: true
    });
    Http.prototype.onError = function () {
        this.nextPost();
    };
    Http.prototype.send = function (k, v) {
        this._cache.push([k, v]);
        this.post();
    };
    Http.prototype.HttpGetRes = function (k, v) {
    };
    Http.prototype.onGet = function () {
    };
    Http.prototype.nextOnGet = function () {
    };
    Http.prototype.get = function (k, v) {
    };
    Http.prototype.onHttpGetComplete = function () {
    };
    Http.prototype.onGetComplete = function () {
    };
    Http.prototype.post = function () {
        if (!this._isRequesting && 0 != this._cache.length) {
            var dat_arr = this._cache.shift();
            var type = dat_arr[0];
            var data = dat_arr[1];
            this._type = type;
            this._request.data = data;
            this._urlLoader.addEventListener(egret.Event.COMPLETE, this.onLoaderComplete, this);
            this._urlLoader.load(this._request),
                this._isRequesting = !0;
        }
    };
    Http.prototype.onLoaderComplete = function () {
        this._urlLoader.removeEventListener(egret.Event.COMPLETE, this.onLoaderComplete, this);
        var json_dat = JSON.parse(this._urlLoader.data);
        // json_dat.hasOwnProperty("s") && 0 != json_dat.s ? Log.trace("Http错误:" + json_dat.s) : (this._data.pUpdate.update(this._type, json_dat), App.MessageCenter.dispatch(this._type, json_dat)),
    };
    Http.prototype.nextPost = function () {
        this._isRequesting = !1;
    };
    return Http;
}(BaseClass));
__reflect(Http.prototype, "Http");
//# sourceMappingURL=Http.js.map