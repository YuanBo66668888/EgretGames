var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var UTFMsg = (function () {
    function UTFMsg() {
    }
    UTFMsg.prototype.receive = function () {
    };
    UTFMsg.prototype.send = function () {
    };
    UTFMsg.prototype.decode = function () {
    };
    UTFMsg.prototype.encode = function () {
    };
    return UTFMsg;
}());
__reflect(UTFMsg.prototype, "UTFMsg");
//# sourceMappingURL=UTFMsg.js.map