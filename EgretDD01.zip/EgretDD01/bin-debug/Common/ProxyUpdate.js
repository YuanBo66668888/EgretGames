var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var ProxyUpdate = (function () {
    function ProxyUpdate(data) {
        this._cache = data;
        this._proxys = [];
    }
    ProxyUpdate.prototype.isArray = function (arr) {
        return arr instanceof Array;
    };
    ProxyUpdate.prototype.isObject = function (object) {
        return object.indexOf("object") > -1;
    };
    ProxyUpdate.prototype.isNormal = function (o) {
        var e = o.indexOf("@") > -1, i = o.indexOf(".") > -1, n = o.indexOf("_") > -1;
        return !e && !i && !n;
    };
    ProxyUpdate.prototype.isAddToArray = function (o) {
        return "@a" == o;
    };
    ProxyUpdate.prototype.isRemoveToArray = function (o) {
        var e = o.split("_");
        return e.length <= 3 && "@d" == e[0];
    };
    ProxyUpdate.prototype.isFilter = function (o) {
        var e = o.split("_");
        return "@f" == e[0];
    };
    ProxyUpdate.prototype.isNumeric = function (o) {
        return parseFloat(o).toString() == o.toString();
    };
    ProxyUpdate.prototype._updateObject = function (o, obj, arr) {
        var n = o.split(".");
        "@a" == n[0] || "@s" == n[0] ? arr[n[1]] = obj : "@d" == n[0] && delete obj[n[1]];
    };
    ProxyUpdate.prototype._getFilterObject = function (obj, arr) {
        if (arr) {
            var i = obj.split("_");
            if (3 == i.length && "@f" == i[0] && this.isArray(arr))
                for (var n = i[1], s = i[2], r = 0; r < arr.length; r++) {
                    var a = arr[r];
                    if (3 == i.length && this.isObject(a.toString())) {
                        var o = a[n];
                        if (o && ("@" == s[0] && (s = s.replace("@", "")), s == o))
                            return a;
                    }
                }
        }
        return null;
    };
    ProxyUpdate.prototype._addObjectToArray = function (arr, obj) {
        if (this.isArray(obj))
            for (var i = 0; i < obj.length; i++)
                arr.push(obj[i]);
        else
            arr.push(obj);
    };
    // TODO
    ProxyUpdate.prototype._removeObjectFromArray = function () {
    };
    ProxyUpdate.prototype.addProxys = function (key, value) {
        if (!this._proxys[key]) {
            this._proxys[key] = [];
        }
        if (-1 == this._proxys[key].indexOf(value)) {
            this._proxys[key].push(value);
        }
    };
    ProxyUpdate.prototype.update = function () {
        // TODO
    };
    ProxyUpdate.prototype._update = function () {
        // TODO
    };
    return ProxyUpdate;
}());
__reflect(ProxyUpdate.prototype, "ProxyUpdate");
//# sourceMappingURL=ProxyUpdate.js.map