var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var GuideConst = (function () {
    function GuideConst() {
    }
    return GuideConst;
}());
__reflect(GuideConst.prototype, "GuideConst");
//# sourceMappingURL=GuideConst.js.map