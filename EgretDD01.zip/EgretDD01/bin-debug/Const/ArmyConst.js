var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var ArmyConst = (function () {
    function ArmyConst() {
    }
    return ArmyConst;
}());
__reflect(ArmyConst.prototype, "ArmyConst");
//# sourceMappingURL=ArmyConst.js.map