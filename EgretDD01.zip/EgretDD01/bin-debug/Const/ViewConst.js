var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var ViewConst = (function () {
    function ViewConst() {
    }
    return ViewConst;
}());
ViewConst.Loading = 1e4;
ViewConst.Login = 10001;
ViewConst.Main = 10002;
ViewConst.Border = 10003;
ViewConst.Home = 100021;
ViewConst.Build = 100022;
ViewConst.Army = 100023;
ViewConst.Skill = 100024;
ViewConst.Union = 100025;
ViewConst.Shop = 100026;
ViewConst.Set = 100027;
ViewConst.Fight = 100028;
ViewConst.Jehad = 100029;
ViewConst.UnionDonateFood = 100400;
ViewConst.UnionDonateWood = 100401;
ViewConst.UnionDonateStone = 100402;
ViewConst.JoinUnion = 100403;
ViewConst.UnionNone = 100404;
ViewConst.BuildUnion = 100405;
ViewConst.CreateUnion = 100406;
ViewConst.UnionFlagPanel = 100407;
ViewConst.InputPanel = 100408;
ViewConst.ChatPanel = 100409;
ViewConst.MsgPanel = 1004010;
ViewConst.Friend = 110003;
ViewConst.Warehouse = 110005;
ViewConst.Factory = 110006;
ViewConst.Task = 110007;
ViewConst.Daily = 110008;
ViewConst.Mail = 110009;
ViewConst.Game = 2e4;
ViewConst.GameUI = 20001;
ViewConst.SignInPanel = 15001;
ViewConst.ActivityPanel = 15002;
ViewConst.SignInWeekPanel = 15003;
ViewConst.BulletScreen = 15004;
__reflect(ViewConst.prototype, "ViewConst");
//# sourceMappingURL=ViewConst.js.map