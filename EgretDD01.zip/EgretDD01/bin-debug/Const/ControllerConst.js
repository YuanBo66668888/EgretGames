var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var ControllerConst = (function () {
    function ControllerConst() {
    }
    return ControllerConst;
}());
ControllerConst.Loading = 1e4;
ControllerConst.Login = 10001;
ControllerConst.Main = 10002;
ControllerConst.Border = 10003;
ControllerConst.Home = 100021;
ControllerConst.Build = 100022;
ControllerConst.Army = 100023;
ControllerConst.Skill = 100024;
ControllerConst.Union = 100025;
ControllerConst.Shop = 100026;
ControllerConst.Set = 100027;
ControllerConst.Fight = 100028;
ControllerConst.Jehad = 100029;
ControllerConst.Game = 2e4;
ControllerConst.Panel = 20001;
ControllerConst.BulletScreen = 20002;
ControllerConst.Gift = 30001;
__reflect(ControllerConst.prototype, "ControllerConst");
//# sourceMappingURL=ControllerConst.js.map