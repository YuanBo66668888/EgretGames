var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var NationConsts = (function () {
    function NationConsts() {
    }
    return NationConsts;
}());
NationConsts.NEED_NUMBER = 1e5;
NationConsts.NANTION_ITEM = 55001;
NationConsts.FREE_COUNT = 1;
NationConsts.COST_ITEM = 1;
NationConsts.COST_GOLD = 500;
NationConsts.COST_SOURCE = 1e3;
__reflect(NationConsts.prototype, "NationConsts");
//# sourceMappingURL=NationConsts.js.map