var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var LoadingConst = (function () {
    function LoadingConst() {
    }
    return LoadingConst;
}());
__reflect(LoadingConst.prototype, "LoadingConst");
//# sourceMappingURL=LoadingConst.js.map