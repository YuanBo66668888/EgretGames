var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var LoadingController = (function () {
    function LoadingController() {
    }
    return LoadingController;
}());
__reflect(LoadingController.prototype, "LoadingController");
//# sourceMappingURL=LoadingController.js.map